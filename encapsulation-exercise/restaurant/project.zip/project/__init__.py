def product():
    return None